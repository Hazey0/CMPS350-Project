const date=new Date();
console.log(date.toString())
date.setMonth(3)
console.log(date.getFullYear()+" "+date.getMonth()+" "+date.getDate()+"  "+date.getHours()+" "+date.getMinutes());