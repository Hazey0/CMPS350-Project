
const getPage = (a) => a.split("/").reduce((a, v) => v)
export const yourPath = getPage(window.location.pathname);
 export const mainPath = "main.html";
 const prevData = localStorage.getItem("prevPath");
 export const prevPath = JSON.parse(prevData);
//console.log("current :" + yourPath)
//console.log("previous:" + prevPath);